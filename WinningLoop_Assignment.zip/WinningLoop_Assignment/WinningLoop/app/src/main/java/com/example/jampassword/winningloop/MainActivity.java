package com.example.jampassword.winningloop;

import android.content.Intent;
import android.content.IntentSender;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.location.Location;
import android.net.Uri;
import android.os.Environment;
import android.provider.MediaStore;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.location.LocationListener;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationServices;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends AppCompatActivity implements
        GoogleApiClient.ConnectionCallbacks,
        GoogleApiClient.OnConnectionFailedListener,
        LocationListener {
    final int CAMERA_REQUEST_CODE = 101;
    final int MEDIATYPE_IMAGE = 1;
    final String IMAGE_EXT = ".jpg";
    final String IMAGE_DIR_NAME = "MyAppImage";
    Uri fileuri;

    ImageView img_view_capture;
    ImageButton img_btn_capture;
    Button btn_submin, btn_discard;
    TextView txtLat;
    String filename, mediasep;
    File rfile = null;

    private final static int CONNECTION_FAILURE_RESOLUTION_REQUEST = 9000;
    private GoogleApiClient mGoogleApiClient;
    private LocationRequest mLocationRequest;
    private double currentLatitude;
    private double currentLongitude;

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode == CAMERA_REQUEST_CODE && resultCode == RESULT_OK) {
            viewCaptureImage();
        }
    }
    //display the image into imageView box
    private void viewCaptureImage() {
        img_view_capture.setVisibility(ImageView.VISIBLE);
        BitmapFactory.Options options = new BitmapFactory.Options();
        options.inSampleSize = 8;
        Bitmap bitmap = BitmapFactory.decodeFile(fileuri.getPath(), options);
        img_view_capture.setImageBitmap(bitmap);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //initiate all variable
        initView();
        mGoogleApiClient = new GoogleApiClient.Builder(this)
                // The next two lines tell the new client that “this” current class will handle connection stuff
                .addConnectionCallbacks(this)
                .addOnConnectionFailedListener(this)
                        //fourth line adds the LocationServices API endpoint from GooglePlayServices
                .addApi(LocationServices.API)
                .build();

        // Create the LocationRequest object
        mLocationRequest = LocationRequest.create()
                .setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY)
                .setInterval(10 * 1000)        // 10 seconds, in milliseconds
                .setFastestInterval(1 * 1000); // 1 second, in milliseconds
    }

    @Override
    protected void onResume() {
        super.onResume();
        //Now lets connect to the API
        mGoogleApiClient.connect();
    }

    @Override
    protected void onPause() {
        super.onPause();
        Log.v(this.getClass().getSimpleName(), "onPause()");

        //Disconnect from API onPause()
        if (mGoogleApiClient.isConnected()) {
            LocationServices.FusedLocationApi.removeLocationUpdates(mGoogleApiClient, this);
            mGoogleApiClient.disconnect();
        }
    }

     //If connected get latitude and longitude
    @Override
    public void onConnected(Bundle bundle) {
        Location location = LocationServices.FusedLocationApi.getLastLocation(mGoogleApiClient);
        if (location == null) {
            LocationServices.FusedLocationApi.requestLocationUpdates(mGoogleApiClient, mLocationRequest, this);
        } else {
            //If everything went fine lets get latitude and longitude
            currentLatitude = location.getLatitude();
            currentLongitude = location.getLongitude();
            Toast.makeText(this, "Current Latitude :"+currentLatitude + " Current Longitude " + currentLongitude + "", Toast.LENGTH_LONG).show();
        }
    }

    @Override
    public void onConnectionSuspended(int i) {}

    @Override
    public void onConnectionFailed(ConnectionResult connectionResult) {
        if (connectionResult.hasResolution()) {
            try {
                // Start an Activity that tries to resolve the error
                connectionResult.startResolutionForResult(this, CONNECTION_FAILURE_RESOLUTION_REQUEST);
            } catch (IntentSender.SendIntentException e) {
                // Log the error
                e.printStackTrace();
            }
        } else {
                /*
                 * If no resolution is available, display a dialog to the
                 * user with the error.
                 */
            Log.e("Error", "Location services connection failed with code " + connectionResult.getErrorCode());
        }
    }

     //If location Changes change latitude and longitude
    @Override
    public void onLocationChanged(Location location) {
        currentLatitude = location.getLatitude();
        currentLongitude = location.getLongitude();
        Toast.makeText(this, "Current Latitude :"+currentLatitude + " Current Longitude " + currentLongitude + "", Toast.LENGTH_LONG).show();
    }

    private void initView() {
        img_view_capture = (ImageView)findViewById(R.id.img_capture_view);
        img_btn_capture = (ImageButton)findViewById(R.id.img_btn_capture);
        txtLat = (TextView)findViewById(R.id.tv_location);
        img_btn_capture.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                captureImage();
            }
        });

        //find current location and upload image on server
        btn_submin = (Button)findViewById(R.id.btn_upload);
        btn_submin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //txtLat.setText("CurrentLatitude :"+currentLatitude+" CurrentLongitude :"+currentLongitude);
                String mmm = "IMG_"+filename;
                txtLat.setText("image name :"+mmm+"  file name :"+rfile);
            }
        });

        //close application
        btn_discard = (Button)findViewById(R.id.btn_discard);
        btn_discard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                img_view_capture.setImageResource(R.drawable.img1);
            }
        });
    }

    //image capture
    private void captureImage() {
        Intent mIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        fileuri = getOutputMediaFileUri(MEDIATYPE_IMAGE);
        mIntent.putExtra(MediaStore.EXTRA_OUTPUT, fileuri);
        startActivityForResult(mIntent, CAMERA_REQUEST_CODE);
    }

    private File getOutputMediaFile(int type) {
        mediasep = File.separator.toString();
        File mediaStorageDir = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM),
                IMAGE_DIR_NAME);
        if(!mediaStorageDir.exists())  {
            if(!mediaStorageDir.mkdir()) {
                Toast.makeText(getBaseContext(), "Error:Image Directry is Not Avail.!!!", Toast.LENGTH_LONG).show();
                return null;
            }
        }
        // add file Name
        filename = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(new Date());
        rfile = null;
        if(type == MEDIATYPE_IMAGE) {
            rfile = new File(mediaStorageDir.getPath() + mediasep + "IMG_" + filename + IMAGE_EXT );
        }
        return rfile;
    }

    public Uri getOutputMediaFileUri(int type) {
        File rfile = getOutputMediaFile(type);
        if(rfile != null) {
            return Uri.fromFile(rfile);
        }
        else {
            return null;
        }
    }
}
