<?php 
 
	 include 'connection.php';
	 
	 $name = $_POST['name'];
	 $image = $_POST['image'];
	 $latitute = $_POST['latitute'];
	 $longitute = $_POST['longitute'];
	 //$latitute = "23.658";
	 //$longitute = "25.65";
	 $sql_query = "INSERT INTO winning VALUES  ('$name','$image','$latitute','$longitute')";
	 
	 $res = mysqli_query($conn,$sql_query);
	 
	 if ($res)
	{
	    $response = array();
		$code = "reg_true";
		$message = "image is uploaded successfully";
		array_push($response,array("code"=> $code,"message"=>$message));
		echo json_encode(array("server_response"=>$response));
	  
	}
	else
	{
	   $response = array();
	    $code = "reg_false";
		$message = "image uploading failed try again...";
		array_push($response,array("code"=> $code,"message"=>$message));
		echo json_encode(array("server_response"=>$response));
	}
	mysqli_close($conn);
 ?>